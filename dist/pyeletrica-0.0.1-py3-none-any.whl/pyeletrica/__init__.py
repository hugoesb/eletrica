# Version of pyeletrica package
__version__ = "0.0.1"